//src/service
export const NavLinks = [
  { id: 1, path: "/", text: "Home", isAbsolute: true },
  { id: 2, path: "/produk-indihome", text: "Produk" },
  { id: 3, path: "/promo-indihome", text: "Promo" },
  { id: 4, path: "https://sobat.indihome.co.id/landingpage?pid=RCSpccep9", target:"_blank", text: "Bantuan", isAbsolute: true },
  { id: 5, path: "indihome-area", text: "Indihome-Area", isAbsolute: true },
];
